export const headCells = [
    
    {
      id: "ITEM",
      numeric: false,
      disablePadding: false,
      label: "ITEM",
      width: "100%",
    },
    {
      id: "ITEM_DESC",
      numeric: false,
      disablePadding: false,
      label: "ITEM DESC",
      width: "100%",
    },
    {
      id: "DIFF_ID",
      numeric: false,
      disablePadding: true,
      label: "DIFF ID",
      width: "100%",
    },
    {
      id: "#OF_SKUS",
      numeric: false,
      disablePadding: true,
      label: "VPN",
      width: "#OF SKUS",
    }
]