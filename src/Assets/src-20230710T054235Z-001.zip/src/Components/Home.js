import React from "react";

const Home = () => {
  return <>hh</>;
};

export default Home;
